import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-personnel',
  templateUrl: './manage-personnel.component.html',
  styleUrls: ['./manage-personnel.component.scss']
})
export class ManagePersonnelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
