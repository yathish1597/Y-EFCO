import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-schedule-tabs',
  templateUrl: './schedule-tabs.component.html',
  styleUrls: ['./schedule-tabs.component.scss']
})
export class ScheduleTabsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
