import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-action-grid-view',
  templateUrl: './action-grid-view.component.html',
  styleUrls: ['./action-grid-view.component.scss']
})
export class ActionGridViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
