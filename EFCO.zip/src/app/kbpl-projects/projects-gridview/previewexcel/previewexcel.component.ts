import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-previewexcel',
  templateUrl: './previewexcel.component.html',
  styleUrls: ['./previewexcel.component.scss']
})
export class PreviewexcelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
