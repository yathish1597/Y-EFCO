import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addjobcard-model',
  templateUrl: './addjobcard-model.component.html',
  styleUrls: ['./addjobcard-model.component.scss']
})
export class AddjobcardModelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
