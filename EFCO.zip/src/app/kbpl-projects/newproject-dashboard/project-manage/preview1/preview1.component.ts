import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preview1',
  templateUrl: './preview1.component.html',
  styleUrls: ['./preview1.component.scss']
})
export class Preview1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
