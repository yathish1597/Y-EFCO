import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-financialdetails',
  templateUrl: './financialdetails.component.html',
  styleUrls: ['./financialdetails.component.scss']
})
export class FinancialdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
