import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-de-brief1',
  templateUrl: './de-brief1.component.html',
  styleUrls: ['./de-brief1.component.scss']
})
export class DeBrief1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
