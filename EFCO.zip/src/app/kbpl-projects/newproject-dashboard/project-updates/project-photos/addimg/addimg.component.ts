import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addimg',
  templateUrl: './addimg.component.html',
  styleUrls: ['./addimg.component.scss']
})
export class AddimgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
